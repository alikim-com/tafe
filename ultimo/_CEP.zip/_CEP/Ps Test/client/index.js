var csInterface = new CSInterface();

var openButton = document.querySelector("#open-button");
openButton.addEventListener("click", openDoc);

function openDoc() {
  csInterface.evalScript("openDocument()");
}