function openDocument(){
   var fileRef = new File("D:\\__CU\\Sergey Garanin\\mars\\ai_props.psd");
   var docRef = app.open(fileRef);
 }