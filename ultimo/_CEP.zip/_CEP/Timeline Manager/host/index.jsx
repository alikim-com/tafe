var _proj = null;

function toJSON(res, msg) {
   return '[' + res + ',"' + msg + '"]';
}

function init() {
   _proj = app.project;
   const res = _proj ? true : false;
   const msg = _proj ? 'Project found' : 'No project found';
   return toJSON(res, msg);
}

function executeCommandO(cmdStr) {
   var cmdId = 0;
   cmdId = app.findMenuCommandId(cmdStr);
   if (cmdId == 0) return cmdId;
   app.executeCommand(cmdId);
   return cmdId;
}

function executeCommandM(cmdStr) {
   var cmdId = 0;
   cmdId = app.findMenuCommandId(cmdStr);
   if (cmdId == 0) return cmdId;
   // RevealAllModifiedProperties
   app.executeCommand(2771);
   app.executeCommand(2771);
   app.executeCommand(cmdId);
   return cmdId;
}

function test(mode) {
   var res = false;
   var msg = 'default';

   var comp = _proj.activeItem;
   if (!comp || !(comp instanceof CompItem)) {
      msg = 'No active item or active item is not a comp';
      return toJSON(res, msg);
   }

   var layer = comp.layer(1);
   if (!layer) {
      msg = 'No layer selected';
      return toJSON(res, msg);
   }
   layer.selected = true;

   var cmdStr = 'Reveal Properties with Keyframes';

   var cmdId = mode == 'O' ?
      executeCommandO(cmdStr) : executeCommandM(cmdStr);
   
   if (cmdId == 0) {
      msg = 'Command \'' + cmdStr + '\' id not found';
      return toJSON(res, msg);
   }
   msg = 'Executed \'' + cmdStr + '\' (' + cmdId + ')';

   layer.selected = false;

   return toJSON(res, msg);
}