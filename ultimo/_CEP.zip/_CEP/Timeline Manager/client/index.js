const objToString = obj => {
   if (obj === '')
      return "''";
   else if (!obj) // undefined, null, 0, false, '', ""
      return obj;
   else if (obj.constructor == Array) {
      let reta = '';
      for (let i = 0; i < obj.length; i++) reta += objToString(obj[i]) + ',';
      return '[' + reta.slice(0, -1) + ']';
   }
   else if (obj.constructor == Set) {
      let rets = '';
      for (let item of obj) rets += objToString(item) + ',';
      return 'new Set([' + rets.slice(0, -1) + '])';
   }
   else if (obj.constructor == Object || obj instanceof Object) {
      let reto = '';
      for (let p in obj)
         if (obj.hasOwnProperty(p)) {

            const desc = Object.getOwnPropertyDescriptor(obj, p);
            if (desc.get || desc.set) {
               reto += (desc.get ? desc.get : desc.set) + ',';
            } else {

               const char = p[0].charCodeAt(0);
               const esc = p.indexOf("'") != -1;
               const quo = p.indexOf(' ') != -1 || esc || char > 47 && char < 58;
               const ep = esc ? p.replaceAll("'", "\\'") : p;
               const strp = quo ? `'${ep}'` : ep;
               reto += `${strp}:${objToString(obj[p])},`;
            }
         }
      return '{' + reto.slice(0, -1) + '}';
   }
   else if (obj.constructor == String) {
      const mult = /\r|\n/.exec(obj) ? '`' : "'";
      return `${mult}${obj.replaceAll("'", "\\'")}${mult}`;
   }
   else
      return obj;
};

var csInterface = new CSInterface();

const html = {};
document.querySelectorAll('*[id]').forEach(e => html[e.id] = e);

const main = async () => {

   var res = false;
   var msgInit = '';

   await new Promise(resolve => {
      csInterface.evalScript('init()',
         arr => {
            [res, msgInit] = JSON.parse(arr);
            html.initInfo.textContent = msgInit;
            resolve();
         });
   });

   if (!res) return;

   html.btnTestO.addEventListener('click', () => {
      html.testInfo.textContent = '>>>';
      csInterface.evalScript(`test('O')`,
         arr => {
            const [_, testInfo] = JSON.parse(arr);
            html.testInfo.textContent = testInfo;
         })
   });

   html.btnTestM.addEventListener('click', () => {
      html.testInfo.textContent = '>>>';
      csInterface.evalScript(`test('M')`,
         arr => {
            const [_, testInfo] = JSON.parse(arr);
            html.testInfo.textContent = testInfo;
         })
   });

};

main();