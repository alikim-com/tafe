function main() {
   const proj = app.project;
   const seq = proj.activeSequence;
   if (!proj) return;
   const binItems = proj.rootItem.children;
   const fileNames = [
      'IMG_5133.jpg',
      'IMG_5135.jpg',
      'IMG_5137.jpg'
   ];
   const durNew = parseFloat('2.5');

   //const durName = 'BE.Prefs.StillImages.DurationInSeconds';
   //const canChangeDur = app.properties.doesPropertyExist(durName);
   //var durOld = 1;
   //const persistent = true;
   //const createIfNotExist = false;
   //if (canChangeDur) { 
      //durOld = app.properties.getProperty(durName);
      //app.properties.setProperty(durName, durNew, persistent, createIfNotExist);
   //}
   
   //seq.videoTracks[0].refreshBaseline();
   //seq.setInPoint(0);
   //seq.setOutPoint(7.5);
   
   const vTrackIndex = 0;
   const aTrackIndex = 0;
   var time = 0;
   var curClip = null;
   for (var i = 0; i < 0; i++) {
      curClip = seq.videoTracks[vTrackIndex].clips[i];
      var dur = curClip.duration.ticks;
      curClip.start = '629959680000';
      curClip.end = (parseInt(curClip.start.ticks) + parseInt(dur)).toString();
      $.writeln('-----');
   }
   return;

   var curClipIndex = 0;
   for (var i = 0; i < 3; i++) {
      var itm = binItems[i];
      $.writeln(itm.name);
      if (fileNames.indexOf(itm.name) == -1) continue;
      seq.insertClip(itm, time, vTrackIndex, aTrackIndex);
      curClip = seq.videoTracks[vTrackIndex].clips[curClipIndex];
      curClip.end = curClip.start.seconds + durNew;
      time += durNew;
      curClipIndex++;
   }
   $.writeln('-----');
   //if (canChangeDur) {
     // app.properties.setProperty(durName, durOld, persistent, createIfNotExist);
   //}

   // 0.04 - 1 sec
   // 254016000000 - 1 sec
   // 254016000000 / 25 = 10160640000 - 1 fr

   // 33
   // start
   // .ticks = 0
   // .seconds = 0 
   // duration
   // .ticks = 635040000000 (629959680000)
   // .seconds = 2.5 (2.48)
   // end
   // .ticks = 635040000000 (629959680000)
   // .seconds = 2.5 (2.48)
       
   // 35
   // start
   // .ticks = 640120320000 (629959680000)
   // .seconds = 2.52 (2.48)
   // duration
   // .ticks = 635040000000 (629959680000)
   // .seconds = 2.5 (2.48)
   // end
   // .ticks = 1275160320000 (1259919360000)
   // .seconds = 4.96
   
   // 37
   // start
   // .ticks = 1270080000000 (1259919360000)
   // .seconds = 4.96
   // duration
   // .ticks = 635040000000 (629959680000)
   // .seconds = 2.5 (2.48)
   // end
   // .ticks = 1905120000000
   // .seconds = 7.5 (7.44)
   
   
}

main();