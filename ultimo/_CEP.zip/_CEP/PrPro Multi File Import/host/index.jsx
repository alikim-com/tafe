var proj = null;
var importPath = null;
var files = [];
var filePaths = [];
var fileNames = [];

function toJSON(res, msg) {
   return '[' + res + ',"' + msg + '"]';
}

function init() {
   proj = app.project;
   const res = proj ? true : false;
   const msg = proj ? 'Project ' + proj.name : 'No project found';
   return toJSON(res, msg);
}

function selectFolder() {
   importPath = Folder.selectDialog('Choose import folder');
   const res = importPath ? true : false;
   const msg = importPath ? importPath.absoluteURI : 'No folder chosen';
   return toJSON(res, msg);
}

function getFileNames() {
   if (!importPath) return toJSON(false, 'No import path');
   files = importPath.getFiles();
   if (!files) return toJSON(false, 'Error retrieving files');
   const flen = files.length;
   const res = flen ? true : false;
   const msg = flen ? flen + ' files found' : 'No files found';
   return toJSON(res, msg);
}

function filterFiles(regExp) {
   //regExp = 'IMG_\\d*[13579](\\D|$)';
   //return toJSON(false, regExp);
   if (!files) return toJSON(false, 'No files to filter');
   const re = new RegExp(regExp, "i");
   //return toJSON(true, re.test('IMG_5132.heic'));
   const flen = Math.min(300, files.length);
   filePaths = [];
   fileNames = [];
   var fi = null;
   for (var i = 0; i < flen; i++) {
      fi = files[i];
      if (!re.test(fi.name)) continue;
      filePaths.push(fi.absoluteURI); // absoluteURI, fsName, fullName, name
      fileNames.push(fi.name);
   }
   const fplen = filePaths.length;
   const res = fplen ? true : false;
   const msg = fplen ? fplen + ' files filtered' : 'No files filtered';
   return toJSON(res, msg);
}

function importFiles() {
   if (!filePaths.length) return toJSON(false, 'No files to import');
   const suppressUI = false;
   const targetBin = proj.rootItem;
   if (!targetBin) return toJSON(false, 'No bin to import to');
   const importAsNumberedStills = false;
   const res = proj.importFiles(filePaths, suppressUI, targetBin, importAsNumberedStills);
   const msg = res ? 'Import success' : 'Import failed';
   return toJSON(res, msg);
}

function addFilesSeq(clipDurSec) {
   const seq = proj.activeSequence;
   if (!seq) return toJSON(false, 'Active sequence not found');
   
   const ticksPerSec = 254016000000;
   const ticksPerFrame = parseInt(seq.timebase);
   const clipDurWholeFrames = Math.ceil(clipDurSec * ticksPerSec / ticksPerFrame);
   const clipDurTicks = ticksPerFrame * clipDurWholeFrames;
   
   const binItems = proj.rootItem.children;
   const vTrackIndex = 0;
   const aTrackIndex = 0;
   var startTimeSec = 0;
   var startTimeTicks = 0;
   var endTimeTicks = 0;
   var curClip = null;
   var curClipIndex = 0;
   for (var i = binItems.length - 1; i >= 0; i--) {
      var itm = binItems[i];
      if (fileNames.indexOf(itm.name) == -1) continue;
      seq.insertClip(itm, startTimeSec, vTrackIndex, aTrackIndex);
      curClip = seq.videoTracks[vTrackIndex].clips[curClipIndex];
      endTimeTicks = startTimeTicks + clipDurTicks;
      curClip.start = startTimeTicks.toString();
      curClip.end = endTimeTicks.toString();
      startTimeTicks = endTimeTicks;
      startTimeSec += startTimeTicks / ticksPerSec + 1; // gap, just in case
      curClipIndex++;
   }
   return toJSON(true, curClipIndex + ' clips added');
}